<!-- BEGIN: Main Menu-->
<?php
    /* $user = Auth::user()->roles->rol; */
?>
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item me-auto">
                <a class="navbar-brand" href="/dashboard">
                    <span class="brand-logo">
                        <img src="<?php echo e(asset('images/logo5.png')); ?>" alt="Comercial El Valle" >
                    </span>
                    <h2 class="brand-text text-dark">Comercial El Valle</h2>
                </a>
            </li>
            <li class="nav-item nav-toggle">
                <a class="nav-link modern-nav-toggle pe-0" data-bs-toggle="collapse">
                    <i class="d-none d-xl-block menu-icon font-medium-4 text-dark" data-feather="menu"></i>
                </a>
            </li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class=" nav-item <?php echo e(setActive('dashboard')); ?>">
                <a class="d-flex align-items-center" href="/dashboard">
                    <i data-feather='layout'></i>
                    <span class="menu-title text-truncate" data-i18n="Clientes">Dashboard</span>
                </a>
            </li>
            <li class=" navigation-header">
                <span data-i18n="Apps &amp; Pages">General</span>
                <i data-feather="more-horizontal"></i>
            </li>
            
                <li class="nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather="grid"></i>
                        <span class="menu-title text-truncate">Administrar</span>
                    </a>
                    <ul class="menu-content">
                        <li class="<?php echo e(setActive('departamentos')); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('departamentos')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate">Departamentos</span>
                            </a>
                        </li>
                        <li class="<?php echo e(setActive('areas')); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('areas')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate">Areas</span>
                            </a>
                        </li>
                    </ul>
                </li>
            
                <li class="nav-item <?php echo e(setActive('colaboradores')); ?>">
                    <a class="d-flex align-items-center" href="<?php echo e(route('colaboradores')); ?>">
                        <i data-feather='users'></i>
                        <span class="menu-title text-truncate">Colaboradores</span>
                    </a>
                </li>
            
            <hr>
            
                <li class="nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather='share-2'></i>
                        <span class="menu-title text-truncate">Asignar</span>
                    </a>
                    <ul class="menu-content">
                        <li class="<?php echo e(setActive('asignar')); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('asignar')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate">Jefes Departamentos</span>
                            </a>
                        </li>
                        <li class="<?php echo e(setActive('asignar2')); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('asignar2')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate">Jefes Areas</span>
                            </a>
                        </li>
                        
                    </ul>
                </li>
           
          
            <hr>
            
                <li class=" nav-item">
                    <a class="d-flex align-items-center" href="#">
                        <i data-feather='shopping-bag'></i>
                        <span class="menu-title text-truncate">Solicitudes de Compras</span>
                    </a>
                    <ul class="menu-content">
                       
                            <li class="<?php echo e(setActive('nueva-solicitud')); ?>">
                                <a class="d-flex align-items-center" href="<?php echo e(route('nueva-solicitud')); ?>">
                                    <i data-feather="circle"></i>
                                    <span class="menu-item text-truncate">Registrar Solicitud</span>
                                </a>
                            </li>
                       
                        <li class="<?php echo e(setActive('solicitudes')); ?>">
                            <a class="d-flex align-items-center" href="<?php echo e(route('solicitudes')); ?>">
                                <i data-feather="circle"></i>
                                <span class="menu-item text-truncate">Solicitudes realizadas</span>
                            </a>
                        </li>
                    </ul>
                </li>
            
            
        </ul>
    </div>
</div>
<!-- END: Main Menu-->
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\8° CICLO\5 - INGENIERIA DE SOFTWARE II\Proyecto\SistemaSolicitudes\resources\views/layouts/components/sidebar.blade.php ENDPATH**/ ?>