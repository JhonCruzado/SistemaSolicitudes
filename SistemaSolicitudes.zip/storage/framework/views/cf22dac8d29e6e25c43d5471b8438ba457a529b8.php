<main class="content-body">
    <div class="d-flex justify-content-between mb-2">
        <h2 class="content-header-title float-start mb-0 text-dark">Nueva solicitud de compra</h2>
    </div>
    <?php
        function Nformat($money)
        {
            return number_format($money, 2, '.', ',');
        }
    ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-1">
                                <h3 class="m-0">
                                    <i class="fas fa-box"></i>&nbsp;&nbsp;Solicitud de Aprobación - Proforma de Compra
                                </h3>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-1">
                                <h6 class="m-0">
                                    <div style="margin-bottom: 4px;aling-items:right;" >
                                        <span style="font-weight: bold;">N° Proforma de Compra:</span>
                                        <span></span>
                                    </div><br>
                                    <div style="margin-bottom: 4px;aling-items:right;" >
                                        <span style="font-weight: bold;">Solicitante:</span>
                                        <span></span>
                                    </div><br>
                                    <div style="margin-bottom: 4px;">
                                        <span style="font-weight: bold;">Grado de Urgencia:</span>
                                        <span></span>
                                    </div><br>
                                    <div style="margin-bottom: 4px;">
                                        <span style="font-weight: bold;">Cargo:</span>
                                        <span></span>
                                    </div><br>
                                    <div style="margin-bottom: 4px;">
                                        <span style="font-weight: bold;">Fecha de Solicitud:</span>
                                        <span></span>
                                    </div><br>
                                    <div style="margin-bottom: 4px;">
                                        <span style="font-weight: bold;">Total:</span>
                                        <span>Soles</span>
                                    </div>
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mt-0">
                    <div class="table-responsive bg-white table-shadow">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Cantidad</th>
                                    <th>Precio (S/.)</th>
                                    <th>Producto</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($table) > 0): ?>
                                    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>15</td>
                                            <td>8</td>
                                            <td>Productp 01</td>
                                            <td>120</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center">
                                            No hay registros
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg">
            <div class="card">
                <div class="card-body">
                    <h6>
                        <i class="fas fa-clipboard-list"></i>&nbsp;&nbsp;Datos de la solicitud
                    </h6>
                    <div class="form-group mb-1">
                        <label class="form-label label">Fecha</label>
                        <input type="date" value="<?php echo e(date('Y-m-d')); ?>" class="form-control" type="text" disabled>
                    </div>
                    <div class="form-group mb-1">
                        <label class="form-label label">Cantidad total</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">#</span>
                            </div>
                            <input type="number" class="form-control" placeholder="0.00" wire:model="cantotal" disabled>
                        </div>
                    </div>
                    <div class="form-group mb-1">
                        <label class="form-label label">Total</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">S/</span>
                            </div>
                            <input type="text" class="form-control" wire:model="total" placeholder="0.00" disabled>
                        </div>
                    </div>
                    <div class="text-center">
                        <button wire:click="save" type="button" wire:loading.attr="disabled" class="btn btn-primary mt-1">
                            <i class="fas fa-save"></i>
                            <span>Enviar solicitud</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if($_colaborador): ?>
        <?php echo $__env->make('livewire.solicitudes.colaboradores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php $__env->startPush('js'); ?>
        <script>
            var isRtl = $('html').attr('data-textdirection') === 'rtl'
            const url = 'nueva-venta';
            window.addEventListener('alertSuccess', event => {
                toastr['success'](`${event.detail.text}`, `${event.detail.title}`, {
                    closeButton: true,
                    tapToDismiss: false,
                    progressBar: true,
                    rtl: isRtl
                });
            });
            window.addEventListener('alertWarning', event => {
                toastr['warning'](`${event.detail.text}`, `${event.detail.title}`, {
                    closeButton: true,
                    tapToDismiss: false,
                    progressBar: true,
                    rtl: isRtl
                });
            })
        </script>
    <?php $__env->stopPush(); ?>
</main>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\8° CICLO\5 - INGENIERIA DE SOFTWARE II\Proyecto\SistemaSolicitudes\resources\views/livewire/solicitudes/mensaje.blade.php ENDPATH**/ ?>