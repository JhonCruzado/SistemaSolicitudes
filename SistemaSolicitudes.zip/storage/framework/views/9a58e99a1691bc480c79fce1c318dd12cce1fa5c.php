<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => ['class' => 'modal-md']]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'modal-md']); ?>
    <div class="modal-header">
        <h6 class="modal-title m-title" id="myModalLabel33">
            <b class="text-wprimary">Procesar </b> - Solicitud
        </h6>
    </div>
    <form wire:submit.prevent="procesarsolicitud(2)" class="needs-validation" name="apertura" novalidate>
        <div class="modal-body">
            <div class="row">
                <div class="col-lg">
                    <h6>
                        <i class="fal fa-paper-plane"></i></i>&nbsp;&nbsp;Información de la solicitud de compra
                    </h6>
                    <div class="row">
                        <div class="col-lg col-md mb-1">
                             <p>La solicitud de compra tiene las aprobaciones necesarias para su procesamiento, por ende esta será enviada por correo electrónico al área de Logística para su procesamiento y adquisición</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button wire:click="limpiarCampos" type="button" class="btn btn-outline-dark">Cancelar</button>
            <button type="submit" class="btn btn-primary">Procesar</button>
        </div>
    </form>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\8° CICLO\5 - INGENIERIA DE SOFTWARE II\Proyecto\SistemaSolicitudes\resources\views/livewire/solicitudes/procesar.blade.php ENDPATH**/ ?>