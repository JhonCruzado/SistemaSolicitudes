<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Tarjeta Kardex</title>
    <style>
        html {
            font-family: sans-serif;
            font-size: 13px;
        }

        #documento {
            border: 1px solid #000;
            padding: 3px 5px;
        }

        .header-container,
        .box-container {
            border: 1px solid #000;
            border-radius: 8px;
        }

        .header {
            width: 100%;
            text-align: center;
        }

        .header tbody tr td,
        .content tbody tr td {
            padding: 5px;
        }

        .header tbody tr td span {
            display: block;
        }

        .header-left {
            border-left: 1px solid #000;
        }

        .content,
        .detail,
        .values {
            width: 100%;
        }

        .detail tbody tr td {
            padding: 3px;
        }

        .values tbody tr td {
            padding: 2px;
        }

        .border {
            border-width: 1px;
            border-color: #000;
            border-style: solid;
        }

        .b-right {
            border-left: 1px solid #000;
        }

        .b-bottom {
            border-bottom: 1px solid #000;
        }

    </style>
</head>

<body>
    <?php
        function Nformat($money)
        {
            return number_format($money, 2, '.', ',');
        }
    ?>
    <header class="header-container">
        <table class="header">
            <tbody>
                <tr>
                    <td width="65%" class="header-right">
                        <span style="font-weight: bold; margin-bottom: 3px; font-size: 15px;"><?php echo e($empresa->nombre); ?></span>
                        <span><?php echo e($empresa->direccion); ?></span>
                        <span>Tel: <?php echo e($empresa->telefono); ?></span>
                    </td>
                    <td class="header-left">
                        <span style="font-weight: bold; margin-bottom: 3px;">TARJETA KARDEX</span>
                        <span>RUC: <?php echo e($empresa->ruc); ?></span>
                    </td>
                </tr>
            </tbody>
        </table>
    </header><br>
    <section class="box-container">
        <table class="content">
            <tbody>
                <tr>
                    <td>
                        <div style="margin-bottom: 3px;">
                            <span style="font-weight: bold;">Fecha de Emisión:</span>
                            <span><?php echo e(date('d/m/Y H:i A')); ?></span>
                        </div>
                        <div style="margin-bottom: 3px;">
                            <span style="font-weight: bold;">Producto:</span>
                            <span><?php echo e($kardex[0]->productos->producto); ?></span>
                        </div>
                        <div style="margin-bottom: 3px;">
                            <span style="font-weight: bold;">Cantidad Total:</span>
                            <span><?php echo e($kardex[$kardex->count() - 1]->stock_total); ?></span>
                        </div>
                        <div>
                            <span style="font-weight: bold;">Valor Total:</span>
                            <span><?php echo e(Nformat($kardex[$kardex->count() - 1]->valor_total)); ?></span>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </section><br>
    <section class="box-container" style="padding: 8px">
        <table class="detail table-bordered" style="border-collapse: collapse; font-size: 12px; text-align: center;">
            <thead style="border-bottom: 1px solid #000">
                <tr>
                    <th colspan="4" class="b-bottom"></th>
                    <th colspan="2" class="b-right b-bottom" style="color: #28c76f; padding: 5px 0">ENTRADAS</th>
                    <th colspan="2" class="b-right b-bottom" style="color: #ea5455">SALIDAS</th>
                    <th colspan="2" class="b-right b-bottom" style="color: #7367f0">SALDO</th>
                </tr>
                <tr>
                    <th>Fecha</th>
                    <th>N° Documento</th>
                    <th>Operación</th>
                    <th>Valor Unitario</th>
                    <th class="b-right">Cantidad</th>
                    <th>Valor</th>
                    <th class="b-right">Cantidad</th>
                    <th>Valor</th>
                    <th class="b-right">Cantidad</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kardex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="10%"><?php echo e(date('d/m/Y', strtotime($k->fecha))); ?></td>
                        <td width="15%"><?php echo e($k->nrodocumento); ?></td>
                        <td width="8%" class="text-center">
                            <?php echo e($k->operacion); ?>

                        </td>
                        <td width="10%"><?php echo e(Nformat($k->valor_unitario)); ?></td>
                        <td class="b-right"><?php echo e($k->operacion == 'Compra' ? $k->cantidad : 0); ?></td>
                        <td><?php echo e($k->operacion == 'Compra' ? Nformat($k->valor) : 0); ?></td>
                        <td class="b-right"><?php echo e($k->operacion == 'Venta' ? $k->cantidad : 0); ?></td>
                        <td><?php echo e($k->operacion == 'Venta' ? Nformat($k->valor) : 0); ?></td>
                        <td class="b-right"><?php echo e($k->stock_total); ?></td>
                        <td><?php echo e(Nformat($k->valor_total)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
</body>

</html>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\SistemaVentasOlano\resources\views/livewire/kardex/pdf.blade.php ENDPATH**/ ?>