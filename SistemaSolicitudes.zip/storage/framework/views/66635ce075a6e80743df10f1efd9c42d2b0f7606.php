<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    
    <div class="container-fluid">
        <div class="full-box tile-container">
            <a href="<?php echo e(route('adm-productos')); ?> " class="tile">
                <div class="tile-tittle">Productos</div>
                <div class="tile-icon">
                    <i class="fas fa-cubes fa-fw"></i>
                </div>
            </a>
            <a href="<?php echo e(route('categorias')); ?>" class="tile">
                <div class="tile-tittle">Categorías</div>
                <div class="tile-icon">
                    <i class="fas fa-tags fa-fw"></i>
                </div>
            </a>
            <a href="<?php echo e(route('sub-categorias')); ?>" class="tile">
                <div class="tile-tittle">Sub Categorías</div>
                <div class="tile-icon">
                    <i class="fas fa-tag fa-fw"></i>
                </div>
            </a>
            <a href="<?php echo e(route('clientes')); ?>" class="tile">
                <div class="tile-tittle">Clientes</div>
                <div class="tile-icon">
                    <i class="fas fa-users fa-fw"></i>
                </div>
            </a>
            <a href="<?php echo e(route('proveedores')); ?>" class="tile">
                <div class="tile-tittle">Proveedores</div>
                <div class="tile-icon">
                    <i class="fas fa-shipping-fast fa-fw"></i>
                </div>
            </a>
            <a href="<?php echo e(route('productos')); ?>" class="tile">
                <div class="tile-tittle">Mostrar</div>
                <div class="tile-icon">
                    <i class="fas fa-th-list"></i>
                </div>
            </a>
            <a href="#" class="tile">
                <div class="tile-tittle">Reportes</div>
                <div class="tile-icon">
                    <i class="fas fa-folder-open fa-fw"></i>
                    
                </div>
            </a>
            <a href="#" class="tile">
                <div class="tile-tittle">Inventario</div>
                <div class="tile-icon">
                    <i class="fas fa-clipboard fa-fw"></i>
                </div>
            </a>
            <a href="<?php echo e(route('nueva-venta')); ?>" class="tile">
                <div class="tile-tittle">Ventas</div>
                <div class="tile-icon">
                    <i class="fas fa-shopping-cart fa-fw"></i>
                </div>
            </a>
            <a href="#" class="tile">
                <div class="tile-tittle">Almacen</div>
                <div class="tile-icon">
                    <i class="fas fa-warehouse fa-fw"></i>
                </div>
            </a>
            <a href="<?php echo e(route('caja')); ?>" class="tile">
                <div class="tile-tittle">Movimientos</div>
                <div class="tile-icon">
                    <i class="fas fa-cash-register fa-fw"></i>
                </div>
            </a>
            


        </div>
    </div>
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\sistema-ventas\resources\views/dashboard.blade.php ENDPATH**/ ?>