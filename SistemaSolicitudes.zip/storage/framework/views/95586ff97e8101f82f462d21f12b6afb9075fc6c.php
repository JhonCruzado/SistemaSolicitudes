<main>
    <div class="content-detached content-right pb-1">
        <div class="content-body">
            <!-- E-commerce Content Section Starts -->
            <section id="ecommerce-header">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="ecommerce-header-items">
                            <div class="result-toggler">
                                <button class="navbar-toggler shop-sidebar-toggler" type="button"
                                    data-bs-toggle="collapse">
                                    <span class="navbar-toggler-icon d-block d-lg-none"><i
                                            data-feather="menu"></i></span>
                                </button>
                                <div class="search-results"><?php echo e($productos->count() . ' de ' . $total); ?> de productos
                                </div>
                            </div>
                            <div class="view-options d-flex">
                                <div class="btn-group" role="group">
                                    <input type="radio" class="btn-check" name="radio_options" id="radio_option2"
                                        autocomplete="off" checked />
                                    <label class="btn btn-icon btn-outline-primary view-btn list-view-btn"
                                        for="radio_option2"><i class="fas fa-th-large"></i></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- E-commerce Content Section Starts -->

            <!-- background Overlay when sidebar is shown  starts-->
            <div class="body-content-overlay"></div>
            <!-- background Overlay when sidebar is shown  ends-->

            <!-- E-commerce Search Bar Starts -->
            <section id="ecommerce-searchbar" class="ecommerce-searchbar">
                <div class="row mt-1">
                    <div class="col-sm-12">
                        <div class="input-group input-group-merge">
                            <input wire:model="search" type="text" class="form-control search-product" id="shop-search"
                                placeholder="Buscar Producto" aria-label="Search..." aria-describedby="shop-search" />
                            <span class="input-group-text"><i data-feather="search" class="text-muted"></i></span>
                        </div>
                    </div>
                </div>
            </section>
            <!-- E-commerce Search Bar Ends -->

            <!-- E-commerce Products Starts -->
            <section id="ecommerce-products" class="grid-view">
                <?php if(count($productos)): ?>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card ecommerce-card shadow">
                        <div class="item-img text-center justify-content-center">
                            <a href="javascript:void(0);">
                                <img class="img-fluid card-img-top" src="<?php echo e(asset('storage/' . $p->foto)); ?>"
                                    alt="img-placeholder" title="<?php echo e($p->producto); ?>"/></a>
                        </div>
                        <div class="card-body">
                            <div class="item-wrapper">
                                <div class="item-rating">
                                    <ul class="unstyled-list list-inline d-none">
                                        <li class="ratings-list-item"><i data-feather="star" class="filled-star"></i>
                                        </li>
                                        <li class="ratings-list-item"><i data-feather="star" class="filled-star"></i>
                                        </li>
                                        <li class="ratings-list-item"><i data-feather="star" class="filled-star"></i>
                                        </li>
                                        <li class="ratings-list-item"><i data-feather="star" class="filled-star"></i>
                                        </li>
                                        <li class="ratings-list-item"><i data-feather="star" class="unfilled-star"></i>
                                        </li>
                                    </ul>
                                </div>
                                <div>
                                    <h6 class="item-price"><?php echo e('S/' . number_format($p->precio_venta, 2)); ?></h6>
                                </div>
                            </div>
                            <h6 class="item-name mb-1">
                                <a class="text-body" href="javascript:void(0);"><?php echo e($p->producto); ?></a>
                            </h6>
                            <div class="item-wrapper">
                                <div class="row flex-column">
                                    <div class="col-lg">
                                        <i class="fad fa-box"></i>
                                        <b>&nbsp;Stock:&nbsp;</b><?php echo e($p->stock); ?>

                                    </div>
                                    <div class="col-lg">
                                        <i class="fad fa-ruler"></i>
                                        <b>&nbsp;Medida:&nbsp;</b><?php echo e($p->medidas->medida); ?>

                                    </div>
                                    <div class="col-lg">
                                        <i class="fad fa-calendar-alt"></i>
                                        <b>&nbsp;Vencimiento:&nbsp;</b>
                                        <?php echo e($p->fecha_vence ? date('d/m/Y', strtotime($p->fecha_vence)) : 'No vence'); ?>

                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="item-options text-center">
                            <div class="item-wrapper">
                                <div class="item-cost">
                                    <h4 class="item-price"><?php echo e('S/' . number_format($p->precio_venta, 2)); ?></h4>
                                </div>
                            </div>
                            <a href="#" class="btn btn-light btn-wishlist" style="cursor: default">
                                <i class="fas fa-barcode"></i>
                                <span><?php echo e($p->id_producto); ?></span>
                            </a>
                            <a href="#" class="btn btn-primary btn-cart btn-copy" aria-label="<?php echo e($p->id_producto); ?>">
                                <i class="far fa-copy"></i>
                                <span class="add-to-cart">Copiar SKU</span>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <span>No hay productos</span>
                <?php endif; ?>
            </section>
            <!-- E-commerce Products Ends -->

            <!-- E-commerce Pagination Starts -->
            <section class="d-flex justify-content-center">
                <?php echo e($productos->links()); ?>

            </section>
            <!-- E-commerce Pagination Ends -->
        </div>
    </div>
    <div class="sidebar-detached sidebar-left">
        <div class="sidebar">
            <!-- Ecommerce Sidebar Starts -->
            <div class="sidebar-shop">
                <div class="row">
                    <div class="col-sm-12">
                        <h6 class="filter-heading d-none d-lg-block">Filtros</h6>
                    </div>
                </div>
                <div class="card shadow">
                    <div class="card-body">
                        <!-- Categories Starts -->
                        <div id="product-categories">
                            <h6 class="filter-title mt-0">Categorias</h6>
                            <ul class="list-unstyled categories-list">
                                <li>
                                    <div class="form-check p-0">
                                        <input wire:model="categoria" type="radio" id="category" name="category"
                                            class="" value="" checked />
                                        <label class="form-check-label" for="category">Todo</label>
                                    </div>
                                </li>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="form-check p-0">
                                            <input wire:model="categoria" type="radio"
                                                id="category<?php echo e($c->categoria_id); ?>" name="category"
                                                class="" value="<?php echo e($c->categoria_id); ?>" />
                                            <label class="form-check-label" for="category<?php echo e($c->categoria_id); ?>">
                                                <?php echo e($c->categorias->categoria); ?>

                                            </label>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Categories Ends -->

                        <!-- Brands starts -->
                        <div class="brands">
                            <h6 class="filter-title">Subcategorias</h6>
                            <ul class="list-unstyled brand-list">
                                <li>
                                    <div class="form-check p-0">
                                        <input wire:model="subcategoria" type="radio" id="sub" name="subcategory"
                                            class="" value="" checked />
                                        <label class="   form-check-label" for="sub">Todo</label>
                                    </div>
                                </li>
                                <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="form-check p-0">
                                            <input wire:model="subcategoria" type="radio"
                                                id="sub<?php echo e($s->id_subcategoria); ?>" name="subcategory"
                                                class="" value="<?php echo e($s->id_subcategoria); ?>" />
                                            <label class="form-check-label" for="sub<?php echo e($s->id_subcategoria); ?>">
                                                <?php echo e($s->subcategoria); ?>

                                            </label>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Brand ends -->

                        <!-- Clear Filters Starts -->
                        <div id="clear-filters">
                            <button wire:click="limpiar" type="button" class="btn w-100 btn-primary">Limpiar
                                filtros</button>
                        </div>
                        <!-- Clear Filters Ends -->
                    </div>
                </div>
            </div>
            <!-- Ecommerce Sidebar Ends -->
        </div>
    </div>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/vendors/css/extensions/nouislider.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/pages/dashboard-ecommerce.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/pages/app-ecommerce.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('rs/vendors/js/extensions/wNumb.min.js')); ?>"></script>
        <script src="<?php echo e(asset('rs/vendors/js/extensions/nouislider.min.js')); ?>"></script>
        <script src="<?php echo e(asset('rs/js/scripts/pages/app-ecommerce.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
        <script>
            var isRtl = $('html').attr('data-textdirection') === 'rtl';

            function copyToClipboard(value) {
                var tempInput = document.createElement('input');
                tempInput.value = value;
                document.body.appendChild(tempInput);
                tempInput.select();
                toastr['success'](tempInput.value.split("'")[1], 'SKU copiado! 📋', {
                    closeButton: true,
                    tapToDismiss: false,
                    rtl: isRtl
                });
                document.execCommand('copy');
                document.body.removeChild(tempInput);
            }
            $(document).on('click', '.btn-copy', function(e) {
                code = e.currentTarget.ariaLabel;
                copyToClipboard(code);
            });
        </script>
    <?php $__env->stopPush(); ?>
</main>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - CADENA DE SUMINISTROS\PROYECTO INVESTIGACIÓN\SistemaVentasOlano\resources\views/livewire/adm-productos/viewall.blade.php ENDPATH**/ ?>