    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/vendors/css/extensions/toastr.min.css')); ?>">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/principal.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/themes/bordered-layout.css')); ?>">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/core/menu/menu-types/vertical-menu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/plugins/extensions/ext-component-toastr.css')); ?>">
    <!-- END: Page CSS-->
    <?php echo $__env->yieldPushContent('styles'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <?php if(auth()->guard()->check()): ?>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
            integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('rs/css/pages/page-auth.css')); ?>">
    <?php endif; ?>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\sistema-ventas\resources\views/layouts/components/css.blade.php ENDPATH**/ ?>