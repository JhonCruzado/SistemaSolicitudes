<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => ['class' => 'modal-lg']]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'modal-lg']); ?>
    <div class="modal-header">
        <h6 class="modal-title m-title" id="myModalLabel33">
            <b class="text-wprimary">Buscar</b> - Cliente
        </h6>
        <button type="button" class="btn-close" wire:click="$set('_cliente',false)"></button>
    </div>
    <div class="modal-body">
        <div class="input-group input-group-merge mb-1">
            <span class="input-group-text" id="basic-addon-search2">
                <i class="far fa-search"></i>
            </span>
            <input wire:model="search" type="text" class="form-control" placeholder="Buscar cliente..."/>
        </div>
        <div class="table-responsive bg-white table-shadow position-relative">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Nombres</th>
                        <th>Documento</th>
                        <th>N° Documento</th>
                        <th class="text-center">Agregar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td width="45%"><?php echo e($c->nombre); ?></td>
                            <td><?php echo e($c->tipos->tipo); ?></td>
                            <td><?php echo e($c->nrodocumento); ?></td>
                            <td class="text-center">
                                <button type="button"
                                    class="btn btn-flat-primary "
                                    wire:click="addCliente(<?php echo e($c->id_cliente); ?>)" wire:loading.attr="disabled">
                                    <i class="far fa-plus"></i>
                                </button>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="rotate" wire:loading wire:target="search">
                <i class="far fa-spinner-third fa-2x"></i>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\sistema-ventas\resources\views/livewire/ventas/clientes.blade.php ENDPATH**/ ?>