
<?php $__env->startSection('reportes'); ?>
    <main>
        <div class="d-flex justify-content-between mb-2">
            <h2 class="content-header-title float-start mb-0 text-dark">Reporte de ventas</h2>
        </div>
        <section class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div id="barchart_values" style="height: 350px;"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div id="productos" style="height: 350px;"></div>
                    </div>
                </div>
            </div>
        </section>
        <?php $__env->startPush('scripts'); ?>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
        <?php $__env->stopPush(); ?>
        <?php $__env->startPush('js'); ?>
            <script type="text/javascript">
                google.charts.load("current", {
                    packages: ["corechart"]
                });
                google.charts.setOnLoadCallback(draw_ingresos);
                google.charts.setOnLoadCallback(draw_productos);

                var chartArea = {
                    left: "10%",
                    top: "10%",
                    height: "100%",
                    width: "90%"
                };
                let ingresos = [
                    ["Mes", "Monto", {
                        role: "style"
                    }],
                    ['Enero', 0, '#1E88E5'],
                    ['Febrero', 0, '#C62828'],
                    ['Marzo', 0, '#3F51B5'],
                    ['Abril', 0, '#039BE5'],
                    ['Mayo', 0, '#009688'],
                    ['Junio', 0, '#FBC02D'],
                    ['Julio', 0, '#4CAF50'],
                    ['Agosto', 0, '#00C853'],
                    ['Septiembre', 0, '#CDDC39'],
                    ['Octubre', 0, '#3949AB'],
                    ['Noviembre', 0, '#FF7043'],
                    ['Diciembre', 0, '#607D8B']
                ];

                function draw_ingresos() {
                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        var mes = <?php echo e($v->mes); ?>;
                        ingresos[mes][1]=parseFloat(<?php echo e($v->total); ?>);
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    var data = google.visualization.arrayToDataTable(ingresos);

                    var view = new google.visualization.DataView(data);

                    view.setColumns([0, 1,
                        {
                            calc: "stringify",
                            sourceColumn: 1,
                            type: "string",
                            role: "annotation"
                        },
                        2
                    ]);

                    var options = {
                        title: "Ingresos por Mes del Año Actual",
                        chartArea,
                        bar: {
                            groupWidth: "95%"
                        },
                        legend: {
                            position: "none"
                        },

                    };
                    var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
                    chart.draw(view, options);
                }

                function draw_productos() {
                    var data = google.visualization.arrayToDataTable([
                        ['Productos', 'Cantidad'],
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            [`<?php echo e($p->producto); ?>`,<?php echo e($p->importe); ?>],
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]);

                    var options = {
                        title: 'Top 10 productos más vendidos',
                        is3D: true,
                        chartArea,
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('productos'));
                    chart.draw(data, options);
                }

                $(document).ready(function() {
                    $(window).resize(function() {
                        draw_ingresos();
                        draw_productos();
                    });
                });
            </script>
        <?php $__env->stopPush(); ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\SistemaVentasOlano\resources\views/livewire/reportes/rep-ventas.blade.php ENDPATH**/ ?>