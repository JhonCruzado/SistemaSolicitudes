<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Reporte de Movimientos</title>
    <style>
        html {
            font-family: sans-serif;
            font-size: 13px;
        }

        #documento {
            border: 1px solid #000;
            padding: 3px 5px;
        }

        .header-container,
        .box-container {
            border: 1px solid #000;
            border-radius: 8px;
        }

        .header {
            width: 100%;
            text-align: center;
        }

        .header tbody tr td,
        .content tbody tr td {
            padding: 5px;
        }

        .header tbody tr td span {
            display: block;
        }

        .header-left {
            border-left: 1px solid #000;
        }

        .content,
        .detail,
        .values {
            width: 100%;
        }

        .detail tbody tr td {
            padding: 3px;
        }

        .values tbody tr td {
            padding: 2px;
        }

        .border {
            border-width: 1px;
            border-color: #000;
            border-style: solid;
        }

        .b-right {
            border-left: 1px solid #000;
        }

        .b-bottom {
            border-bottom: 1px solid #000;
        }

    </style>
</head>

<body>
    <?php
        function Nformat($money)
        {
            return number_format($money, 2, '.', ',');
        }
    ?>
    <header class="header-container">
        <table class="header">
            <tbody>
                <tr>
                    <td width="65%" class="header-right">
                        <span style="font-weight: bold; margin-bottom: 3px; font-size: 15px;"><?php echo e($empresa->nombre); ?></span>
                        <span><?php echo e($empresa->direccion); ?></span>
                        <span>Tel: <?php echo e($empresa->telefono); ?></span>
                    </td>
                    <td class="header-left">
                        <span style="font-weight: bold; margin-bottom: 3px;">REPORTE DE MOVIMIENTOS</span>
                    </td>
                </tr>
            </tbody>
        </table>
    </header><br>
    <section class="box-container">
        <table class="content">
            <tbody>
                <tr>
                    <td>
                        <div style="margin-bottom: 3px;">
                            <span style="font-weight: bold;">Fecha de Emisión:</span>
                            <span><?php echo e(date('d/m/Y H:i A')); ?></span>
                        </div>
                        <div style="margin-bottom: 3px;">
                            <span style="font-weight: bold;">Cantidad Movimientos:</span>
                            <span><?php echo e($reporte->count()); ?></span>
                        </div>
                        <div>
                            <span style="font-weight: bold;">Monto Actual en Caja:</span>
                            <span><?php echo e(Nformat($lastregister->saldo)); ?></span>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </section><br>
    <section class="box-container" style="padding: 8px">
        <table class="detail table-bordered" style="border-collapse: collapse; font-size: 12px; text-align: center;">
            <thead style="border-bottom: 1px solid #000">
                
                <tr>
                    <th>Hora</th>
                    <th>Operación</th>
                    <th>Tipo Movimiento</th>
                    <th>Monto</th>
                    <th>Saldo</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reporte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="10%"><?php echo e(\Carbon\Carbon::parse($r->fecha)->toTimeString()); ?></td>
                        <td width="10%" class="text-center">
                            <?php echo e($r->descripcion); ?>

                        </td>
                        <?php if($r->tipoMovimiento == 1): ?>
                            <td width="10%">Ingreso</td>
                        <?php else: ?>
                            <td width="10%">Egreso</td>
                        <?php endif; ?>
                        <?php if($r->monto < 0): ?>
                            <td width="10%"><?php echo e(Nformat($r->monto*-1)); ?></td>
                        <?php else: ?>
                            <td width="10%"><?php echo e(Nformat($r->monto)); ?></td>
                        <?php endif; ?>
                        <td width="10%"><?php echo e(Nformat($r->saldo)); ?></td>
                        <?php if($r->estadoMovimiento == 1): ?>
                            <td width="10%">Procesado</td>
                        <?php else: ?>
                            <td width="10%">Cancelado</td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
</body>

</html>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - CADENA DE SUMINISTROS\PROYECTO INVESTIGACIÓN\SistemaVentasOlano\resources\views/livewire/cajas/reporteMovimientos.blade.php ENDPATH**/ ?>