<div>
    <div class="modal fade text-start fade show" id="inlineForm" style="display: block;" tabindex="-1"
        aria-labelledby="myModalLabel33" aria-hidden="true" role="dialog">
        <div <?php echo e($attributes->merge(['class' => 'modal-dialog modal-dialog-centered'])); ?>>
            <div class="modal-content">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
</div>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\8° CICLO\5 - INGENIERIA DE SOFTWARE II\Proyecto\SistemaSolicitudes\resources\views/components/modal.blade.php ENDPATH**/ ?>