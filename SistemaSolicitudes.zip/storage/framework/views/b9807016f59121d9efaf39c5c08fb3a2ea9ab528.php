<!-- BEGIN: Vendor JS-->
<script src="<?php echo e(asset('rs/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN Vendor JS-->

<?php if(auth()->guard()->check()): ?>
    <script src="<?php echo e(asset('rs/vendors/js/extensions/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('rs/js/scripts/extensions/ext-component-toastr.js')); ?>"></script>
<?php endif; ?>

<!-- BEGIN: Theme JS-->
<script src="<?php echo e(asset('rs/js/core/app-menu.js')); ?>"></script>
<script src="<?php echo e(asset('rs/js/core/app.js')); ?>"></script>
<!-- END: Theme JS-->

<?php echo $__env->yieldPushContent('scripts'); ?>

<script>
    $(window).on('load', function() {
        if (feather) {
            feather.replace({
                width: 14,
                height: 14
            });
        }
    })
</script>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\sistema-ventas\resources\views/layouts/components/js.blade.php ENDPATH**/ ?>