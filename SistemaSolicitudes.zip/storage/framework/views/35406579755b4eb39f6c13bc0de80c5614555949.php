<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => ['class' => 'modal-lg']]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'modal-lg']); ?>
    <div class="modal-header">
        <h6 class="modal-title m-title" id="myModalLabel33">
            <b class="text-wprimary">Detalle</b> - Compra
        </h6>
        <button type="button" class="btn-close" wire:click="$set('_detalle2',false)"></button>
    </div>
    <?php
        $i = 0;
    ?>
    <div class="modal-body">
        <div class="table-responsive bg-white table-shadow">
            <table class="table table-hover" style="text-align:center">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Precio</th>
                        <th>Descuento</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detallecompra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $de): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i += 1); ?></td>
                            <td width="60%"><?php echo e($de->productos->producto); ?></td>
                            <td style="text-align:center"><?php echo e(number_format($de->cantidad)); ?></td>
                            <td style="text-align:center"><?php echo e(number_format($de->precio)); ?></td>
                            <td style="text-align:center"><?php echo e(number_format($de->descuento)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="container mt-3">
                <?php $__currentLoopData = $compra2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col">
                            <div class="row">
                                <div class="col-10" style="text-align:right">
                                    <p><b>Sub Total:</b></p>
                                </div>
                                <div class="col" style="text-align:center">
                                  <p>S/. <?php echo e(number_format($co->subtotal)); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-10" style="text-align:right">
                                    <p><b>IGV (18%):</b></p>
                                </div>
                                <div class="col" style="text-align:center">
                                    <p>S/. <?php echo e(number_format($co->igv)); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-10" style="text-align:right">
                                    <p><b>Total:</b></p>
                                </div>
                                <div class="col" style="text-align:center">
                                    <p>S/. <?php echo e(number_format($co->total)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\SistemaVentasOlano\resources\views/livewire/cajas/detallecompra.blade.php ENDPATH**/ ?>