<main class="content-body">
    <div class="d-flex justify-content-between mb-2">
        <h2 class="content-header-title float-start mb-0 text-dark">Historial de Movimientos</h2>
    </div>
    <div class="d-flex justify-content-between mb-2">
        <button type="button" class="btn btn-primary" wire:click="$set('_ingreso', true)">
            <i data-feather='plus-circle'></i></i>&nbsp;&nbsp;Ingreso&nbsp;&nbsp;
        </button>
        <button type="button" class="btn btn-primary" wire:click="$set('_aperturacaja', true)">
            &nbsp;&nbsp;Abrir Caja&nbsp;&nbsp;<i data-feather='unlock'></i>
        </button>
        <button type="button" class="btn btn-danger" wire:click="$set('_cierrecaja', true)">
            &nbsp;&nbsp;Cerrar Caja&nbsp;&nbsp;<i data-feather='lock'></i>
        </button>
        <button type="button" class="btn btn-danger" wire:click="$set('_egreso, true)">
            <i data-feather='minus-circle'></i></i>&nbsp;&nbsp;Egreso&nbsp;&nbsp;
        </button>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card box-shadow">
                <div class="card-body">
                    <h6 class="mb-1">Filtros</h6>
                    <div class="row">
                        <div class="col-lg">
                            <div class="input-group input-group-merge">
                                <span class="input-group-text" id="basic-addon-search2">
                                    <i class="far fa-search"></i>
                                </span>
                                <input wire:model="search" type="text" class="form-control" placeholder="Buscar movimiento..."
                                    aria-label="Buscar movimiento..." aria-describedby="basic-addon-search2" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 mb-4">
            <div class="table-responsive bg-white box-shadow">
                <table class="table table-hover">
                    <thead class="table-secondary">
                        <tr>
                            <th>ID</th>
                            <th>Fecha / Hora</th>
                            <th>Descripción</th>
                            <th>Monto</th>
                            <th>Saldo Actual</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
                <div class="d-flex px-1 align-items-center">
                    <div class="col-lg-1">
                        <div class="mb-1">
                            <label class="form-label" for="basicSelect">Mostrar</label>
                            <select wire:model="paginate" class="form-select form-select-sm" id="basicSelect">
                                <option value="5">5</option>
                                <option value="10">10</option>
                                <option value="20">20</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg">
                       
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if($_ingreso): ?>
        <?php echo $__env->make('livewire.cajas.ingreso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($_aperturacaja): ?>
        $this->alert('success', 'Hello World!', [
            'position' =>  'top-end',
            'timer' =>  3000,
            'toast' =>  true,
            'text' =>  '',
            'confirmButtonText' =>  'Ok',
            'cancelButtonText' =>  'Cancel',
            'showCancelButton' =>  true,
            'showConfirmButton' =>  false,
        ]);
    <?php endif; ?>
    <?php if($_egreso): ?>
        <?php echo $__env->make('livewire.cajas.egreso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($_cierrecaja): ?>
        <?php echo $__env->make('livewire.cajas.ingreso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</main>
<?php /**PATH D:\Desktop\TRABAJOS\INGENIERIA DE SISTEMAS-UNT\7° CICLO\2 - Cadena de Suministros\Proyecto\sistema-ventas\resources\views/livewire/cajas/movimientos.blade.php ENDPATH**/ ?>