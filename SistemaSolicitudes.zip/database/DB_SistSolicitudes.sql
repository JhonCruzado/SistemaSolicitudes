-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2022 at 07:11 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

drop database if exists Solicitudes;
create database Solicitudes;
use Solicitudes;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `solicitudes`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizarEstado` (IN `nroOrden` BIGINT)  BEGIN
    DECLARE ordenes int;
    DECLARE aprobado int;
    DECLARE nulos int;

    SET ordenes = (SELECT COUNT(*) FROM solicitud WHERE solicitud_id = nroOrden);
    SET aprobado = (SELECT COUNT(*) FROM solicitud WHERE solicitud_id = nroOrden and estado = '1');
    SET nulos = (SELECT COUNT(*) FROM solicitud WHERE solicitud_id = nroOrden and estado IS NULL);
     IF nulos = 0 THEN
        IF aprobado = ordenes THEN
            UPDATE solicitud_compra  set estado = 'Aprobado' where  id_solicitud = nroOrden;
            SELECT 1 as ok;
        ELSE
            UPDATE solicitud_compra  set estado = 'Rechazado' where  id_solicitud = nroOrden;
        END IF;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `id_area` int(11) NOT NULL,
  `area` varchar(40) NOT NULL,
  `departamento_id` int(11) NOT NULL,
  `estado` enum('Habilitado','Deshabilitado') NOT NULL DEFAULT 'Habilitado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`id_area`, `area`, `departamento_id`, `estado`) VALUES
(1, 'Tesoreria', 1, 'Habilitado'),
(2, 'Contabilidad', 1, 'Habilitado'),
(3, 'Logística', 2, 'Habilitado'),
(4, 'Ventas', 3, 'Habilitado'),
(5, 'Marketing', 3, 'Habilitado');

-- --------------------------------------------------------

--
-- Table structure for table `cargo`
--

CREATE TABLE `cargo` (
  `id_cargo` int(11) NOT NULL,
  `cargo` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cargo`
--

INSERT INTO `cargo` (`id_cargo`, `cargo`) VALUES
(1, 'Colaborador'),
(2, 'Jefe del Area'),
(3, 'Jefe del Departamento'),
(4, 'Gerente General');

-- --------------------------------------------------------

--
-- Table structure for table `colaborador`
--

CREATE TABLE `colaborador` (
  `id_colaborador` bigint(20) NOT NULL,
  `dni` char(8) NOT NULL,
  `nombres` varchar(80) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `telefono` char(15) NOT NULL,
  `email` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `colaborador`
--

INSERT INTO `colaborador` (`id_colaborador`, `dni`, `nombres`, `cargo_id`, `direccion`, `telefono`, `email`) VALUES
(1, '74250635', 'ISAC DANIEL MIÑANO CORRO', 4, 'Trujillo', '987654321', 'samyeshua727@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `colaborador_area`
--

CREATE TABLE `colaborador_area` (
  `id_col_area` int(11) NOT NULL,
  `colaborador_id` bigint(20) NOT NULL,
  `area_id` int(11) NOT NULL,
  `estado` enum('Habilitado','Deshabilitado') NOT NULL DEFAULT 'Habilitado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `colaborador_area`
--

INSERT INTO `colaborador_area` (`id_col_area`, `colaborador_id`, `area_id`, `estado`) VALUES
(11, 37, 4, 'Habilitado'),
(12, 38, 3, 'Habilitado');

-- --------------------------------------------------------

--
-- Table structure for table `colaborador_dep`
--

CREATE TABLE `colaborador_dep` (
  `id_col_dep` int(11) NOT NULL,
  `colaborador_id` bigint(20) NOT NULL,
  `departamento_id` int(11) NOT NULL,
  `estado` enum('Habilitado','Deshabilitado') NOT NULL DEFAULT 'Habilitado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `colaborador_dep`
--

INSERT INTO `colaborador_dep` (`id_col_dep`, `colaborador_id`, `departamento_id`, `estado`) VALUES
(14, 36, 3, 'Habilitado');

-- --------------------------------------------------------

--
-- Table structure for table `departamento`
--

CREATE TABLE `departamento` (
  `id_departamento` int(11) NOT NULL,
  `departamento` varchar(40) NOT NULL,
  `estado` enum('Habilitado','Deshabilitado') NOT NULL DEFAULT 'Habilitado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departamento`
--

INSERT INTO `departamento` (`id_departamento`, `departamento`, `estado`) VALUES
(1, 'Finanzas', 'Habilitado'),
(2, 'Producción', 'Habilitado'),
(3, 'Comercial', 'Habilitado');

-- --------------------------------------------------------

--
-- Table structure for table `detalle_solicitud_compraa`
--

CREATE TABLE `detalle_solicitud_compraa` (
  `id_detalle` bigint(20) NOT NULL,
  `solicitud_id` bigint(20) NOT NULL,
  `producto` varchar(200) NOT NULL,
  `precio` float(8,2) NOT NULL,
  `cantidad` float(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('gPgaAc2615gIasB5bB08EQAE3o1IsVENWqrXqCkW', 37, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiZnk4OEdXdkljdmZzUmtCcXhjUWZENkJQck1OckNsOUJTT2VYVjdqMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozNztzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJDkySVhVTnBrak8wck9RNWJ5TWkuWWU0b0tvRWEzUm85bGxDLy5vZy9hdDIudWhlV0cvaWdpIjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCQ5MklYVU5wa2pPMHJPUTVieU1pLlllNG9Lb0VhM1JvOWxsQy8ub2cvYXQyLnVoZVdHL2lnaSI7fQ==', 1642702269);

-- --------------------------------------------------------

--
-- Table structure for table `solicitud`
--

CREATE TABLE `solicitud` (
  `id` bigint(20) NOT NULL,
  `solicitud_id` bigint(20) NOT NULL,
  `estado` enum('1','0') DEFAULT NULL,
  `colaborador_id` bigint(20) NOT NULL,
  `observacion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `solicitud_compra`
--

CREATE TABLE `solicitud_compra` (
  `id_solicitud` bigint(20) NOT NULL,
  `colaborador_id` bigint(20) NOT NULL,
  `grado_urgencia` varchar(200) NOT NULL,
  `monto_total` float(12,2) NOT NULL,
  `cantidad_total` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `Aprobaciones` int(11) NOT NULL DEFAULT 0,
  `Procesada` varchar(11) DEFAULT NULL,
  `estado` enum('Aprobado','En Proceso','Rechazado') NOT NULL DEFAULT 'En Proceso'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------

--
-- Table structure for table `urgencia`
--

CREATE TABLE `urgencia` (
  `id_urgencia` int(11) NOT NULL,
  `grado` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `urgencia`
--

INSERT INTO `urgencia` (`id_urgencia`, `grado`) VALUES
(1, 'Alto'),
(2, 'Medio'),
(3, 'Bajo');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `estado` enum('Habilitado','Deshabilitado') DEFAULT 'Habilitado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `email`, `password`, `created_at`, `updated_at`, `estado`) VALUES
(4, 'JHON PAUL CRUZADO DE LA CRUZ', 'jcruzadod@unitru.edu.pe', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '2022-01-05 14:31:58', '2021-07-04 09:02:01', 'Habilitado');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`id_area`),
  ADD KEY `departamento_id` (`departamento_id`);

--
-- Indexes for table `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id_cargo`);

--
-- Indexes for table `colaborador`
--
ALTER TABLE `colaborador`
  ADD PRIMARY KEY (`id_colaborador`),
  ADD KEY `rol_id` (`cargo_id`);

--
-- Indexes for table `colaborador_area`
--
ALTER TABLE `colaborador_area`
  ADD PRIMARY KEY (`id_col_area`),
  ADD KEY `colaborador_id` (`colaborador_id`),
  ADD KEY `area_id` (`area_id`);

--
-- Indexes for table `colaborador_dep`
--
ALTER TABLE `colaborador_dep`
  ADD PRIMARY KEY (`id_col_dep`),
  ADD KEY `colaborador_id` (`colaborador_id`),
  ADD KEY `departamento_id` (`departamento_id`);

--
-- Indexes for table `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`id_departamento`);

--
-- Indexes for table `detalle_solicitud_compraa`
--
ALTER TABLE `detalle_solicitud_compraa`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `solicitud_id` (`solicitud_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `solicitud`
--
ALTER TABLE `solicitud`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitud_id` (`solicitud_id`),
  ADD KEY `colaborador_id` (`colaborador_id`);

--
-- Indexes for table `solicitud_compra`
--
ALTER TABLE `solicitud_compra`
  ADD PRIMARY KEY (`id_solicitud`),
  ADD KEY `colaborador_id` (`colaborador_id`);

--
-- Indexes for table `urgencia`
--
ALTER TABLE `urgencia`
  ADD PRIMARY KEY (`id_urgencia`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id_cargo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `colaborador`
--
ALTER TABLE `colaborador`
  MODIFY `id_colaborador` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `colaborador_area`
--
ALTER TABLE `colaborador_area`
  MODIFY `id_col_area` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `colaborador_dep`
--
ALTER TABLE `colaborador_dep`
  MODIFY `id_col_dep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `departamento`
--
ALTER TABLE `departamento`
  MODIFY `id_departamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `detalle_solicitud_compraa`
--
ALTER TABLE `detalle_solicitud_compraa`
  MODIFY `id_detalle` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `solicitud`
--
ALTER TABLE `solicitud`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `solicitud_compra`
--
ALTER TABLE `solicitud_compra`
  MODIFY `id_solicitud` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `urgencia`
--
ALTER TABLE `urgencia`
  MODIFY `id_urgencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `solicitud`
--
ALTER TABLE `solicitud`
  ADD CONSTRAINT `solicitud_ibfk_1` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitud_compra` (`id_solicitud`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `solicitud_ibfk_2` FOREIGN KEY (`colaborador_id`) REFERENCES `colaborador` (`id_colaborador`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
